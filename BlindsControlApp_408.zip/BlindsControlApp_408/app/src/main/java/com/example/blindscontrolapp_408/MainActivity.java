package com.example.blindscontrolapp_408;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity{
    private Button OpenButton;
    private Button CloseButton;
    private Button HalfwayButton;
    private Button AutoButton;
    private TextView Status;
    private TextView LightVal;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference mRootRef = firebaseDatabase.getReference();
    private DatabaseReference BlindStatus = mRootRef.child("Status");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayAdapter<String> menuAdapter;

        OpenButton = findViewById(R.id.OpenBtn);
        CloseButton = findViewById(R.id.ShutBtn);
        HalfwayButton = findViewById(R.id.HalfwayBtn);
        AutoButton = findViewById(R.id.AutoBtn);
        Status = findViewById(R.id.StatusOpenClose);
        LightVal = findViewById(R.id.LightValue);


        Spinner blindsMenu = findViewById(R.id.blindsDropDown);
        menuAdapter = new ArrayAdapter<String>( MainActivity.this, android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.blindsController));
        blindsMenu.setAdapter(menuAdapter);

        //These 4 methods basically update the Database on each click
        OpenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BlindStatus.setValue("Open");
            }
        });

        CloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BlindStatus.setValue("Close");
            }
        });

        HalfwayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BlindStatus.setValue("Halfway");
            }
        });

        AutoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BlindStatus.setValue("Automatic");
            }
        });

        mRootRef.child("Status").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot){
                String status = dataSnapshot.getValue(String.class);
                Status.setText(status);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        mRootRef.child("user").child("LightValue").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String lightval = dataSnapshot.getValue(Integer.class).toString();
                LightVal.setText(lightval);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
